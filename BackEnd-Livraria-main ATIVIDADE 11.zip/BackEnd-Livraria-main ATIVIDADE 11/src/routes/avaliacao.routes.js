import express from "express";
import { criarAvaliacao, listarAvaliacao, obterAvaliacao , desafioExtra}
 from "../controllers/avaliacao.controller.js";

const router = express.Router();


//Desafio Extra 
router.get("/desafioExtra", desafioExtra);

// Criar uma avaliação
router.post("/", criarAvaliacao);

// Listar todas as avaliações
router.get("/", listarAvaliacao);



//Listar por ID
router.get("/:id", obterAvaliacao);

export default router;
