import express from "express"
import {
    criarLivros,
    listarLivros,
    obterLivros,
    atualizarLivros,
    deletarLivros
} from "../controllers/livros.controller.js";

const router = express.Router();

// usuario / //

router.get("/", listarLivros);
router.get("/:id", obterLivros);
router.post("/", criarLivros);
router.put("/:id", atualizarLivros);
router.delete("/:id", deletarLivros);

export default router;