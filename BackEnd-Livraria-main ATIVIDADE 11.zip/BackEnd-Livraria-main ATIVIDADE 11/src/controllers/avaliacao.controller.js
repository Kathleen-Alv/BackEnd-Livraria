import { db } from "../config/db.js";

// ============================
//  Controlador de Avaliações
// ============================

// Criar avaliação
export async function criarAvaliacao(req, res) {
  try {
    const { usuario_id, livro_id, comentario, nota } = req.body;

    if (!usuario_id || !livro_id || !comentario || !nota) {
      return res.status(400).json({ erro: "Campos obrigatórios faltando." });
    }

    await db.execute(
      "INSERT INTO avaliacoes (usuario_id, livro_id, comentario, nota) VALUES (?, ?, ?, ?)",
      [usuario_id, livro_id, comentario, nota]
    );

    res.json({ mensagem: "Avaliação criada com sucesso!" });
  } catch (err) {
    res.status(500).json({ erro: err.message });
  }
}

// Listar avaliações
export async function listarAvaliacao(req, res) {
  try {
    const [rows] = await db.execute("SELECT * FROM avaliacoes");
    res.json(rows);
  } catch (err) {
    res.status(500).json({ erro: err.message });
  }
}


//LIstar por Id

export async function obterAvaliacao(req,res) {
   try {
    const [rows] = await db.execute("SELECT * FROM avaliacoes WHERE id = ?", [
      req.params.id,
    ]);
    if (rows.length === 0)
      return res.status(404).json({ erro: "Avaliação não encontrado , Verifique o ID" });
    res.json(rows[0]);
  } catch (err) {
    res.status(500).json({ erro: err.message });
  }
};
  
//Desafio Extra

export async function desafioExtra(req,res) {
  try{
    const [rows]= await db.execute (
      `
      SELECT 
        l.id AS livro_id,
        l.titulo AS livro_titulo,
        AVG(a.nota) AS media_notas,
        COUNT(a.id) AS total_avaliacoes
      FROM livros l
      LEFT JOIN avaliacoes a ON a.livro_id = l.id
      GROUP BY l.id, l.titulo
      ORDER BY l.titulo
    `);
    res.json(rows);

  }catch(err) {
    res.status(500).json({ erro: err.message });
  }

}
    

 
  
