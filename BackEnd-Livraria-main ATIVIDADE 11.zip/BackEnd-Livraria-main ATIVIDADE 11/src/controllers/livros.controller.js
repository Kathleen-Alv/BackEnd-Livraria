import { db } from "../config/db.js";
// ============================
//  Rotas CRUD
// ============================



export async function criarLivros(req, res) {
  try {
    const { titulo, autor , genero,editora,ano_publicacao, isbn, idioma, formato, caminho_capa, sinopse, ativo, criado_em } = req.body;
    if (!titulo || !autor || !genero || !editora || !ano_publicacao || !isbn || !idioma || !formato || !caminho_capa || !sinopse || !ativo )
      return res.status(400).json({ erro: "Campos obrigatórios" });

    await db.execute(
      "INSERT INTO livros (titulo, autor , genero,editora,ano_publicacao, isbn, idioma, formato, caminho_capa, sinopse, ativo) VALUES (?, ? , ? , ?, ?, ?, ?, ?, ?, ?, ?)",
      [titulo, autor , genero,editora,ano_publicacao, isbn, idioma, formato, caminho_capa, sinopse, ativo]
    );

    res.json({ mensagem: "Livro criado com sucesso!" });
  } catch (err) {
    res.status(500).json({ erro: err.message });
  }
};



export async function listarLivros(req, res) {
  try {
    const [rows] = await db.execute("SELECT * FROM livros");
    res.json(rows);
  } catch (err) {
    res.status(500).json({ erro: err.message });
  }
};


export async function obterLivros(req, res) {
  try {
    const [rows] = await db.execute("SELECT * FROM livros WHERE id = ?", [
      req.params.id,
    ]);
    if (rows.length === 0)
      return res.status(404).json({ erro: "Livro não encontrado" });
    res.json(rows[0]);
  } catch (err) {
    res.status(500).json({ erro: err.message });
  }
};


// Tratamendo de dados para converter undefined em null antes de enviar ao banco.
function limparValores(obj) {
  for (const chave in obj) {
    if (obj[chave] === undefined) {
      obj[chave] = null;
    }
  }
  return obj;
}



export async function atualizarLivros(req, res) {
  try {
    const { id } = req.params;
    const {titulo,autor,genero,editora,ano_publicacao,isbn,idioma,formato,caminho_capa,sinopse,ativo} = req.body;
    const [rows] = await db.execute("SELECT * FROM livros WHERE id = ?", [id]);
    if (rows.length === 0)
      return res.status(404).json({ erro: "Livro não encontrado" });
    const livroAtual = rows[0];

    const livroAtualizado = limparValores ({
      titulo: titulo ?? livroAtual.titulo,
      autor: autor ?? livroAtual.autor,
      genero: genero ?? livroAtual.genero,
      editora: editora ?? livroAtual.editora,
      ano_publicacao: ano_publicacao ?? livroAtual.ano_publicacao,
      isbn: isbn ?? livroAtual.isbn,
      idioma: idioma ?? livroAtual.idioma,
      formato: formato ?? livroAtual.formato,
      caminho_capa: caminho_capa ?? livroAtual.caminho_capa,
      sinopse: sinopse ?? livroAtual.sinopse,
      ativo: ativo ?? livroAtual.ativo
    });

    const camposAlterados = Object.keys(req.body).filter(
      (campo) => req.body[campo] !== undefined
    );

    if (camposAlterados.length === 0) {
      return res
        .status(400)
        .json({ erro: "Nenhum campo foi enviado para atualização." });
    }

    await db.execute(
      `UPDATE livros
       SET titulo = ?, autor = ?, genero = ?, editora = ?, ano_publicacao = ?, isbn = ?, idioma = ?, formato = ?, caminho_capa = ?, sinopse = ?, ativo = ?
       WHERE id = ?`,
      [
        livroAtualizado.titulo,
        livroAtualizado.autor,
        livroAtualizado.genero,
        livroAtualizado.editora,
        livroAtualizado.ano_publicacao,
        livroAtualizado.isbn,
        livroAtualizado.idioma,
        livroAtualizado.formato,
        livroAtualizado.caminho_capa,
        livroAtualizado.sinopse,
        livroAtualizado.ativo,
        id
      ]
    );
    res.json({
      mensagem: ` Os Campos [${camposAlterados.join(", ")}] foram atualizados com sucesso!`
    });
  } catch (err) {
    console.error("Erro ao atualizar livro:", err);
    res.status(500).json({ erro: err.message });
  }
}







export async function deletarLivros(req, res) {
  try {
    await db.execute("DELETE FROM livros WHERE id = ?", [req.params.id]);
    res.json({ mensagem: "Livro deletado com sucesso!" });
  } catch (err) {
    res.status(500).json({ erro: err.message });
  }
};